Application.run(function ($rootScope) {
    "use strict";
});